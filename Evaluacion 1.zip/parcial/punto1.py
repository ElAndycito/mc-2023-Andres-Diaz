Conjunto_1 = []
Conjunto_2 = []
Conjunto_3 = []
Conjunto_4 = []
Conjunto_5 = []
Conjunto_6 = []

#Conjuntos taller #2.
Conjunto_A=[1,4,6,9,12,20,30]
Conjunto_B=[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]
Conjunto_C=[6,10,14,18,22,26,30,34]
Conjunto_D=[]

xd=int(input("Presione 1 para iniciar: "))

def union(Conjunto_1,Conjunto_2,Conjunto_3,Conjunto_4,Conjunto_5,Conjunto_6):
    aea=1
    for i in Conjunto_1:
        for k in Conjunto_3:
            if k==i:
                aea=0
        if aea==0:
            pass
        elif aea==1:
            Conjunto_3.append(i)
        aea=1
    for i in Conjunto_2:
        for k in Conjunto_3:
            if k==i:
                aea=0
        if aea==0:
            pass
        elif aea==1:
            Conjunto_3.append(i)
        aea=1
    return Conjunto_3
def inter(Conjunto_1,Conjunto_2,Conjunto_3,Conjunto_4,Conjunto_5,Conjunto_6):
    aea=1
    for i in Conjunto_1:
        for k in Conjunto_2:
            if k==i:
                aea=0
        if aea==0:
            Conjunto_4.append(i)
        aea=1
    return Conjunto_4
def dif(Conjunto_1,Conjunto_2,Conjunto_3,Conjunto_4,Conjunto_5,Conjunto_6):
    aea=1
    Conjunto_5=Conjunto_1
    for i in Conjunto_1:
        for k in Conjunto_2:
            if k==i:
                aea=0
        if aea==0:
            Conjunto_5.remove(i)
        aea=1
    return Conjunto_5
def difsim(Conjunto_1,Conjunto_2,Conjunto_3,Conjunto_4,Conjunto_5,Conjunto_6):
    a=union(Conjunto_1,Conjunto_2,Conjunto_3,Conjunto_4,Conjunto_5,Conjunto_6)
    b=inter(Conjunto_1,Conjunto_2,Conjunto_3,Conjunto_4,Conjunto_5,Conjunto_6)
    Conjunto_6=dif(Conjunto_3,Conjunto_4,Conjunto_1,Conjunto_2,Conjunto_5,Conjunto_6)
    return Conjunto_6



#Rtas taller 2.
if xd==1:
    a=difsim(Conjunto_C,Conjunto_B,Conjunto_C,Conjunto_B,Conjunto_5,Conjunto_6)
    b=union(Conjunto_A,Conjunto_C,Conjunto_D,Conjunto_C,Conjunto_5,Conjunto_6)
    c=inter(a,b,Conjunto_C,Conjunto_D,Conjunto_5,Conjunto_6)
    print(c)
    a=dif(Conjunto_A,Conjunto_B,Conjunto_C,Conjunto_D,Conjunto_5,Conjunto_6)
    b=inter(a,Conjunto_C,Conjunto_C,Conjunto_C,Conjunto_5,Conjunto_6)
    c=union(Conjunto_B,Conjunto_C,Conjunto_D,Conjunto_C,Conjunto_5,Conjunto_6)
    d=difsim(b,c,Conjunto_C,Conjunto_D,Conjunto_5,Conjunto_6)
    print(d)
    a=dif(Conjunto_A,Conjunto_B,Conjunto_C,Conjunto_D,Conjunto_5,Conjunto_6)
    b=inter(Conjunto_B,Conjunto_A,Conjunto_A,Conjunto_A,Conjunto_5,Conjunto_6)
    c=union(a,b,Conjunto_C,Conjunto_D,Conjunto_5,Conjunto_6)
    d=union(Conjunto_A, Conjunto_B,Conjunto_C,Conjunto_D,Conjunto_5,Conjunto_6)
    e=dif(c,d,Conjunto_C,Conjunto_D,Conjunto_5,Conjunto_6)
    print(e)

else:
    print("Opción inválida.")

