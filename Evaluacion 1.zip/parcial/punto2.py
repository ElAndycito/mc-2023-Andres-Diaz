def factorial(x):
    contador=1
    for i in range(0,x):
        contador=contador*(x-i)
    resultado = contador
    return resultado

def permutacion(n,r):
    perm=factorial(n)/factorial(n-r)
    return perm

def combinacion(n,r):
    comb=factorial(n)/(factorial(r)*factorial(n-r))
    return comb
#c11,3 * c14*4
ejercicio = int(input("Ingrese 1 para ver el resultado: "))
if ejercicio == 1: 
    print("Resultado del a: ")
    a = 25*24*23*22*21*20*19
    print(a)
    print("Resultado del b: ")
    b = 11*10*9*14*13*12*11
    print(b)
    print("Resultado del c: ")
    c=permutacion(25,7)
    print(c)

else:
    print("Número inválido.")